<?php
/**
 * Functions related to the BuddyBoss Access Control Cache.
 *
 * @package BuddyBossPro
 *
 * @since   1.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
